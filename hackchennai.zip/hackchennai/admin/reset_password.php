
<?php
session_start();
include("dbconfig.php");
$_SESSION['userid'] ;
$_SESSION['name'];

    
    $fpwdId = mysqli_real_escape_string($con, $_GET['fpwdId']);
    //echo $fpwdId;
    if ($fpwdId !=""){
        
    $getID = mysqli_fetch_assoc(mysqli_query($con,"select * from login where forgot_pass_identity='$fpwdId' LIMIT 1"));
    $user_id = $getID['id'];
    $user_name = $getID['name'];
    $forgot_password_time = $getID['forgot_password_created_on'];
    
    //current Time stamp 
    date_default_timezone_set('Asia/Kolkata');
    $current_date1 =  date('d-m-Y H:i:s');
    
    $timedifference =  strtotime($current_date1)-strtotime($forgot_password_time);
            if ($timedifference > 1800){
                echo '<p align="center"><h3>Sorry! Link Expired. Please use reset password again .<br>Redirecting to Forgot password!</h3></p>';
                header( "refresh:1;url=http://abcnet.in/admin/forgot-password.php" );
                
            }
    
    
    // echo $user_id;
    // echo $user_name;
    // echo $timedifference;
        
    }
    else{
        echo '<script>window.location.assign("../index.php");</script>';
    }
    


?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Password Change</title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body class="signup-page" style="background-image: url(images/test1.png);">
    <div class="signup-box">
        <div class="logo">
            <img src="images/logo.png" height="150">
        </div>
        <div class="card">
            <div class="body">
			 
                <form id="fupForm" method="POST" action="">
                    <div class="msg">Dear <?echo  '<span style="color: red;" />'.$user_name.' </span>'?>, Create your new password</div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="password" id="pwd" minlength="6" placeholder="Password" required>
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="cfpassword" id="pwd" minlength="6" placeholder="Confirm Password" required>
                        </div>
                    </div>
                    <!--<div class="form-group">-->
                    <!--    <input type="checkbox" name="terms" id="terms" class="filled-in chk-col-pink" required>-->
                    <!--    <label for="terms">I read and agree to the <a href="javascript:void(0);">terms of usage</a>.</label>-->
                    <!--</div>-->
					<div class="row">
					<div class="col-xs-4 p-t-5">
                    <button class="btn btn-block btn-lg bg-pink waves-effect"  name="submit" id="butsave" type="submit">Change Password</button>
					</div>
					</div>
                    <div class="m-t-25 m-b--5 align-center">
                        <a href="index.php">You already have a membership?</a>
                    </div>
                </form>
            
			</div>
        </div>
    </div>
    
    
    
    
    <?php
    
    
            
            	

  if(isset($_POST['submit'])){
  $pwd = $_POST['cfpassword'];
  
  //Get date time 
 	
date_default_timezone_set('Asia/Kolkata');
$current_date1 =  date('d-m-Y H:i:s');
 
      echo $statusMsg;

      
      $sql="UPDATE login SET password = '$pwd',forgot_pass_identity ='',forgot_password_created_on='$current_date1'  WHERE id = '$user_id'";
      


            if( $user_id !=""){
                if(mysqli_query($con, $sql)){
                        echo "<script type='text/javascript'>alert('Password changed Sucessfully!')</script>";
                        echo '<script>window.location.assign("index.php");</script>';
                    
                }
                
            }

     


    }

?>


 <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Validation Plugin Js -->
    <script src="plugins/jquery-validation/jquery.validate.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/login/sign-up.js"></script>
</body>

</html>