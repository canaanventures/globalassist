<?php
   session_start();
   session_destroy();

echo '<script language="javascript">';
echo 'alert("You have sucessfully signed-out")';
echo '</script>';
   echo '<script>window.location.assign("../admin/index.php");</script>';
?>