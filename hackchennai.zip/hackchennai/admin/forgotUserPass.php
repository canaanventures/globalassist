<?php
//Start session
session_start();
// $_SERVER['REQUEST_URI'];
// $userid='';
// $password='';

$role='';

    
//Unset the variables stored in session
require('dbconfig.php');
$email = mysqli_real_escape_string($con, $_POST['email']);




$query = mysqli_query($con,"select email,mobile, cetid from cetlogin where email='$email' or mobile='$email' LIMIT 1");


if(mysqli_num_rows($query)>0 ){
    $row = mysqli_fetch_assoc($query);

    // $password = $row['password'];
    $email = $row['email'];
    $usernumber = $row['mobileno'];
    $userid = $row['cetid'];
echo '<p align="center"><h3>Hello how are you</h3></p>';
    
    //Temporary link 
        do {
    
            $newunique_number  = substr(str_shuffle("1234567890abcdefghijklmnopqrstuvwxyzabcnetabcdefghijklmnopqrstuvwxyz"),0,49);
            //echo $newunique_number;
            $query = "SELECT * FROM cetlogin WHERE forgot_pass_identity='$newunique_number'";
            $dataexist = mysqli_num_rows(mysqli_query($con, $query));
             if ($dataexist ==0)
             {
                date_default_timezone_set('Asia/Kolkata');
                $current_date1 =  date('d-m-Y H:i:s');
                
                $query="UPDATE cetlogin SET forgot_pass_identity = '$newunique_number', forgot_password_created_on ='$current_date1'  WHERE cetid = '$userid'";

                
                if ( mysqli_query($con, $query))
                    {
                    $random_found = 1;
                    
                    }
                 
             }
    
            
    } while ($random_found == 0);
    
    $Resetpwdurl = "http://thebill.in/admin/reset_password.php?fpwdId=$newunique_number";

    
    //Email 
    
    $to = $email;
    $subject = "THE BILL.IN- your Password ";
    $body = "<p>Dear User,<br><br> \n\n Your user id:$usernumber <br><br> Please click this link to reset your password : $Resetpwdurl <br><br>Note: This link will be expired in 30 minutes.<br><br>To comment/suggestion reach us reach2impact@gmail.com<br><br>Regards<br>abcnet.in</p>";
    $headers  = "From: AbcnetIndia <noreply@thebill.in>" . "\r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
    mail($to, $subject, $body, $headers);
    
//if pass send mail
//echo '<script>window.location.assign("http://abcnet.crossedge.in/");</script>';

echo '<p align="center"><h3>Password has been sent to your mail id.Please check your email.</h3></p>';
header( "refresh:3;url=http://thebill.in/index.php" );


//header("Location: http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
}
else{

echo '<script>alert("This mail id/mobile number is not availble in the website. Sorry for the inconvinience.");window.location.assign("forgot-password.php");</script>';
}

?>
