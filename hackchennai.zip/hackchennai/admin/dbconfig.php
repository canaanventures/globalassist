<?php 



$con=mysqli_connect("localhost", "leviticu_mov", "gKPF#yHKLec%", "leviticu_movement") or die('sorry! could not connect');
//echo"connected";
?>