<?php
//Start session
ini_set('session.cookie_lifetime', 60 * 60 * 24 * 30);
ini_set('session.gc-maxlifetime', 60 * 60 * 24 * 30);
session_start();
$_SERVER['REQUEST_URI'];
$userid='';
$password='';

$role='';

    
//Unset the variables stored in session
require('dbconfig.php');
// $country = mysqli_real_escape_string($con,$_POST['country']);

$mobile = mysqli_real_escape_string($con,$_POST['phone']);
$password = mysqli_real_escape_string($con,$_POST['password']);

$query = mysqli_query($con,"select * from abcnetsong_login where mobile='$mobile' AND is_active=1 LIMIT 1");
$no_rows=mysqli_num_rows($query);
$row = mysqli_fetch_assoc($query);
$passwordHashed = $row['pwd'];
if($no_rows>0 && password_verify($password, $passwordHashed)){
$_SESSION['mobile']= $mobile;
$_SESSION['email'] = $row['email'];
$_SESSION['name'] = $row['name'];
    $_SESSION['cetid'] = session_id();
    
    $_SESSION['id'] = $row['cetid'];
    $_SESSION['is_admin'] = $row['is_admin'];
    
    $url =$_SERVER['REQUEST_URI'];

    
    echo '<p align="center"><h3>Login Sucessful.<br>Redirecting to Home screen!</h3></p>';
    header( "refresh:1;url=../dashboard/index.php" );


}else{
    
echo '<script>alert("User id or password is wrong!");window.location.assign("index.php");</script>';
}

?>
