<?php
//Start session
session_start();
$_SERVER['REQUEST_URI'];
$userid='';
$password='';

$role='';

    
//Unset the variables stored in session
require('dbconfig.php');
$email = mysqli_real_escape_string($con,$_POST['email']);



$query = mysqli_query($con,"select password,email,mobileno from login where email='$email' or mobileno='$email' LIMIT 1");


if(mysqli_num_rows($query)>0 ){
    $row = mysqli_fetch_assoc($query);

    $password = $row['password'];
    $email = $row['email'];
    $usernumber = $row['mobileno'];

    
    //Email 
    
    $to = $email;
    $subject = "Abcnet.in - your Password ";
    $body = "<p>Dear User,<br><br> \n\n Your user id:$usernumber <br><br> your password is: $password <br><br>To comment/suggestion reach us reach2impact@gmail.com<br><br>Regards<br>abcnet.in</p>";
    $headers  = "From: AbcnetIndia <noreply@abcnet.in>" . "\r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
    mail($to, $subject, $body, $headers);
    
//if pass send mail
//echo '<script>window.location.assign("http://abcnet.crossedge.in/");</script>';

echo '<p align="center"><h3>Password has been sent to your mail id.Please check your email.</h3></p>';
header( "refresh:3;url=http://abcnet.in/admin/index.php" );


//header("Location: http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
}
else{

echo '<script>alert("This mail id/mobile number is not availble in the website. Sorry for the inconvinience.");window.location.assign("forgot-password.php");</script>';
}

?>
