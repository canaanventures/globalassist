<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}




$id = $_GET['deleteId'];

$sql= "UPDATE `lang_slave` SET langsl_isactive='9' WHERE langsl_id='$id'";


if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Deleted Successfully');
		
		window.location.assign("lang_slave.php");
     </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. DATA NOT DELETED.");</script>'; 
		 echo '<script> window.location.assign("lang_slave.php");</script>';
		 
      }
?>

