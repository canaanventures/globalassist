<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['editId'];

$sql = "SELECT * FROM lang_slave WHERE langsl_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));

$langsl_langId = $output["langsl_langId"];
$langsl_masterid = $output["langsl_masterid"];


$language = "SELECT `language`, `language_ID` FROM `language` where language_ID='$langsl_langId'";
$lang_selected = mysqli_fetch_array(mysqli_query($con, $language));

$master = "SELECT`langmas_data`, `langmas_id` FROM `lang_master` where langmas_id='$langsl_masterid'";
$$master_selected  = mysqli_fetch_array(mysqli_query($con, $master));


function fill_language($con)  
{  
          global $langsl_langId;
          $output = '';  
          $sql = "SELECT `language`, `language_ID` FROM `language` where is_active=1"; 
          $selectproject = mysqli_query($con, $sql);   
          while($row1 = mysqli_fetch_array($selectproject))  
          {  
               if($langsl_langId==$row1["language_ID"]){
               continue;
           }
               $output .= '<option value="'.$row1["language_ID"].'">'.$row1["language"].'</option>';  
          }  
          return $output;  
} 

function fill_master($con)  
{  
           global $langsl_masterid;
          $output = '';  
          $sql = "SELECT `langmas_data`, `langmas_id` FROM `lang_master` where langmas_isactive=1"; 
          $selectmodel = mysqli_query($con, $sql);   
          while($mode = mysqli_fetch_array($selectmodel))  
          {    
               if($langsl_masterid==$mode["langmas_id"]){
               continue;
           }
               $output .= '<option value="'.$mode["langmas_id"].'">'.$mode["langmas_data"].'</option>';  
          }  
          return $output;  
} 

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
   <link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">
</head>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="master_data.php">Master Data</a></li>
                                      <li class="breadcrumb-item active">Edit Master Data</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <!--<div class="col-sm-6" align="right">-->
                                      
                                  <!--    <button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Create Event </button>-->
                                      
                                  <!--</div>
                                  <!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-7">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
             
                <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                   <div class="form-group">
                    <label for="language" >Language</label>
                       <select name="language" class="form-control" required>
                            <option value="<?php echo $lang_selected["language_ID"] ?>"><?php echo $lang_selected["language"] ?></option>     
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="master" >Master Data</label>
                       <select name="master" class="form-control" required>
                         <option value="<?php echo $$master_selected["langmas_id"] ?>" ><?php echo $$master_selected["langmas_data"] ?></option>     
                           <?php  echo fill_master($con); ?>
                      </select>
                  </div>
                  
                   <div class="form-group">
                    <label for="data">Data</label>
                    <textarea name="data" class="form-control" id="data"><?php echo $output["langsl_data"]; ?></textarea>
                </div>
               </div>  
               
                  <button type="submit" name="update" class="btn btn-primary mt-4">Update</button>
               </form>
            </div>
           
        </div>    
  </div>


<?php
      
 if(isset($_POST['update'])){  
      
  $language = mysqli_real_escape_string($con,$_POST['language']);
  $master = mysqli_real_escape_string($con,$_POST['master']);
  $data = mysqli_real_escape_string($con,$_POST['data']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 

$sql=("UPDATE `lang_slave` SET langsl_langId='$language',langsl_masterid='$master',langsl_data='$data',langsl_createdon='$current_date', langsl_createdby='$user_id' WHERE langsl_id='$id'");

  if (mysqli_query($con, $sql)) {
   ?>
    <script>
       alert('Updated Successfully');
		window.location.assign("lang_slave.php");
    </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("lang_slave.php");</script>';

    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }
 }
   
?>

   
  </div>
</main>
<br/><br/>  

<?php include("../footer.php"); ?>	


</body>
</html>
