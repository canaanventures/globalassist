<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


// echo "<script type='text/javascript'>alert('$user_id');</script>";



function add($con)
    {     
                    
          
                       echo '<table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col" style="width:15px;">S.No</th>
                                                <th scope="col">Lang Name</th>
                                                <th scope="col">Master Name</th>
                                                <th scope="col">Data</th>
                                                <th scope="col">Active / Inactive</th>
                                                <th scope="col">Edit</th>
                                                <th scope="col">Delete</th>
                                            </tr>
                                        </thead>';
                               
                           
                                $query ="SELECT `lang_master`.`langmas_data`,`language`.`language`,`lang_slave`.`langsl_data`,`lang_slave`.`langsl_id`,`lang_slave`.`langsl_isactive` FROM `lang_slave` 
                                                   INNER JOIN lang_master ON `lang_master`.`langmas_id`=`lang_slave`.`langsl_masterid` 
                                                   INNER JOIN `language` ON `language`.`language_ID`=`lang_slave`.`langsl_langId` where langsl_isactive<5";
                                $result=mysqli_query($con,$query);
                                
                                $var = 1;
                                while($row = mysqli_fetch_array($result))
                                {
                                    
                                   $is_active =$row['langsl_isactive'];
                                    
                                     if($is_active==1){
                                        $data="la-eye";
                                        
                                    } elseif ($is_active==0){
                                         $data="la-eye-slash";
                                        
                                    }
                                    
                                    
                                      echo ' <tr>';
                                      echo '<td data-title="S.No." >'.$var++.'</td>';
                                      echo '<td data-title="Lang Name" style="text-transform: capitalize;">' .$row["language"]. '</td>';
                                      echo '<td data-title="Master Name">' .$row["langmas_data"]. '</td>';
                                      echo '<td data-title="Data">' .$row["langsl_data"]. '</td>';
                                      echo '<td data-title="Active/Inactive" style="text-align: center;"><a type="button" href="lang_slave_active.php?Id='.$row["langsl_id"].'" data-toggle="tooltip" title="Active / Inactive" data-placement="left">
                                      <i class="la '.$data.'" style="font-size:22px;padding-right: 10px;"></i></a></td>';
                                     
                                      echo '<td data-title="Edit"><a type="button" href="lang_slave_edit.php?editId='.$row["langsl_id"].'">
                                      <i class="la la-edit" style="font-size:22px;padding-right: 10px;"></i></a></td>';
                                      
                                       echo '<td data-title="Delete"><a type="button" href="lang_slave_delete.php?deleteId='.$row["langsl_id"].'">
                                      <i class="la la-trash" style="font-size:22px;padding-right: 10px;"></i></a></td>';
                                      echo '</tr>';
                                   }
                              echo '</table>';
 }
   
   
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>

<style>
    .dataTables_length {
         margin-bottom: 35px;
}


</style>

<body>

<?php include("../header.php"); ?>

    <div id="layoutSidenav_content">
        <main>
           
        <div class="container-fluid mt-5 mb-5">
          
           <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                      <div class="col-sm-6">
                        <h5 class="m-0 text-dark">Master Data</h5>
                      </div><!-- /.col -->
                      <div class="col-sm-6" align="right">
                          
                          <a type="button" class="btn btn-primary btn-sm" href="add_lang_slave.php"><span class="icon la la-plus-square"></span>Add Language Data</a>
                         
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
                        
                        
    <div class="panel-body mt-5">
        
         <div id="no-more-tables" style="clear: both;">       
            <?php echo add($con);?>
         </div>
  
    </div>
    
        </div>
    </main>



<?php include("../footer.php"); ?>	

<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
