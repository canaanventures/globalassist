<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['Id'];

 $val1 = abs($langsl_isactive-=1);
  
   $sql= ("UPDATE `lang_slave` SET langsl_isactive=IF(langsl_isactive=1, 0, 1) WHERE langsl_id='$id'");
   if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("lang_slave.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("lang_slave.php");</script>';
		 
      }
?>

