<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}

function fill_language($con)  
{  
         
          $output = '';  
          $sql = "SELECT `language`, `language_ID` FROM `language` where is_active=1"; 
          $selectproject = mysqli_query($con, $sql);   
          while($row1 = mysqli_fetch_array($selectproject))  
          {  
               $output .= '<option value="'.$row1["language_ID"].'">'.$row1["language"].'</option>';  
          }  
          return $output;  
} 

function fill_master($con)  
{  
         
          $output = '';  
          $sql = "SELECT `langmas_data`, `langmas_id` FROM `lang_master` where langmas_isactive=1"; 
          $selectmodel = mysqli_query($con, $sql);   
          while($mode = mysqli_fetch_array($selectmodel))  
          {  
               $output .= '<option value="'.$mode["langmas_id"].'">'.$mode["langmas_data"].'</option>';  
          }  
          return $output;  
} 


?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
   <link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">
</head>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="lang_slave.php">Language Data</a></li>
                                      <li class="breadcrumb-item active">Add Language Data</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <!--<div class="col-sm-6" align="right">-->
                                      
                                  <!--    <button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Create Event </button>-->
                                      
                                  <!--</div>
                                  <!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-8">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
             
              <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="language" >Language</label>
                       <select name="language" class="form-control" required>
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="master" >Master Data</label>
                       <select name="master" class="form-control" required>
                             <?php  echo fill_master($con); ?>
                      </select>
                  </div>
                
                <div class="form-group">
                    <label for="data">Data</label>
                    <textarea name="data" class="form-control" id="description" required></textarea>
                </div>
             </div>    
                  <button type="submit" name="submit" class="btn btn-primary mt-4">Submit</button>
                
              </form>
            </div>
           
        </div>    
  </div>


<?php
             
  if(isset($_POST['submit'])){  
      
  $language = mysqli_real_escape_string($con,$_POST['language']);
  $master = mysqli_real_escape_string($con,$_POST['master']);
  $data = mysqli_real_escape_string($con,$_POST['data']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
   $sql="INSERT INTO `lang_slave`( `langsl_langId`,`langsl_masterid`, `langsl_data`,`langsl_createdon`,`langsl_createdby`) VALUES 
                  ('$language','$master', '$data', '$current_date','$user_id')";

  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Added Successfully');
		window.location.assign("lang_slave.php");
        </script>
        
  <?php  
  }
      else {
		
// 		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
// 		echo '<script> window.location.assign("lang_slave.php");</script>';
		
      echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

   
  </div>
</main>
<br/><br/>  

<?php include("../footer.php"); ?>	


</body>
</html>
