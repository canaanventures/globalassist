<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



function add($con)
         {     
         
                    global $user_id;
                     
                    echo '<table class="table table-borderless">
                      <thead>
                        <tr>
                       
                          <th ></th>
                          <th ></th>
                        
                        </tr>
                      </thead>';
                      
                       $query ="SELECT * FROM abcnetsong_login where cetid='$user_id' ";
                       $result=mysqli_query($con,$query);
                       
                        while($row = mysqli_fetch_array($result))
                        
                           {
                           
                            $id=$row["cetid"];
                            $name = $row['name'];
                            $countrycode = $row['countrycode'];
                            $mobile = $row['mobile'];
                            $email = $row['email'];
                            
                            $date =$row['createdOn'];
                            $date1 = explode(" ",$date)[0];
                            $newDateTime = date('h:i A', strtotime($date));
                            
                            $sql = mysqli_query($con,"select name from country where phonecode='$countrycode'");
                            
                            $row=mysqli_fetch_assoc($sql);
                            
                            $code=$row['name'];
                            
                            $query = mysqli_query($con,"select zone_name from zone where zone_id='$tngtimezone' LIMIT 1");
                            
                            $row=mysqli_fetch_assoc($query);
                            
                            $timezone = $row['zone_name'];
                            
                            //  echo'<img src="../upload/'. $tng_image.'" class="img-fluid"  alt="Responsive Image" width="130" height="150" />';
                             
                  echo'<tbody>
                        <tr>
                          <td>Name</td>
                          <td style="text-transform: capitalize;">'.$name. '</td>
                        </tr>
                        <tr>
                          <td>Mobile Number</td>
                          <td>'.$countrycode.' '.$mobile.'</td>
                        </tr>
                       
                        <tr>
                          <td>Email</td>
                          <td>'.$email.'</td>
                        </tr>
                         <tr>
                          <td>Created On</td>
                          <td>'.$date1.'</td>
                        </tr>
                       </tbody>';
                    
                        }
                        
                   echo' </table>';
                      
  }
   
   
?>


<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">

<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<style>
    .dataTables_length {
         margin-bottom: 5px;
}

.field-icon {
    float: right;
    margin-top: -25px;
    position: relative;
    z-index: 2;
    font-size: 20px;
    margin-right: 15px;
}

</style>

</head>
<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                <div class="container-fluid mt-5">
                    
                <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                      <div class="col-sm-6">
                        <h5 class="m-0 text-dark">Profile</h5>
                      </div><!-- /.col -->
                      
                      <div class="col-sm-6" align="right">
                          
                         <!--<a type="button" class="btn btn-primary btn-sm" href="edit_profile.php"><span class="icon la la-pencil-square"></span>Edit Profile</a>-->
                      </div>
                        </div><!-- /.row -->
                       
                      </div><!-- /.container-fluid -->
                    </div>
                    
                        <div class="panel-body col-lg-5 mt-5 mb-5">
                            
                             <div style="clear:both;">       
                                <?php echo add($con);?>
					         </div>
					    </div>
					    
					   <div class="col-sm-6">
                        
                        <a type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal"><span class="icon la la-pencil"></span>Reset Password</a>
                      
                      </div>
 

                 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Reset your Password</h5>
                                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                 </div>
                                 <div class="modal-body">
                                    <form id=""  action="" method="post" enctype="multipart/form-data"> 
                                      <div class="form-group">
                                        <p>Please enter your password below to reset</p>  
                                        
                                        <label for="recipient-name" class="col-form-label">Current Password</label>
                                        <input type="password" class="form-control" name="oldpassword" id="oldpwd"  required>
                                      </div>
                                      
                                      <div class="form-group">
                                          
                                        <label for="message-text" class="col-form-label">New Password</label>
                                        <input type="password" class="form-control pwd" name="password" id="pwd" minlength="6"  required>
                                         <span class="icon la la-eye field-icon reveal"></span>
                                      </div>
                                      
                                      <script>
                                              $(".reveal").on('click',function() {
                                                var $pwd = $(".pwd");
                                                if ($pwd.attr('type') === 'password') {
                                                    $pwd.attr('type', 'text');
                                                } else {
                                                    $pwd.attr('type', 'password');
                                                }
                                            });
                                      </script>
                                          
                                      <div class="form-group">
                                       <label for="message-text" class="col-form-label">confirm New password</label>
                                        <input type="password" class="form-control pwd" name="confirmpassword" id="confirmpwd" minlength="6"  required>
                                       
                                      <br/>
                                       <span id='message'></span> 
                                      </div>
                                      
                                  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>


                                  <div class="modal-footer">
                                    <button class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button name="reset" class="btn btn-primary">Submit</button>
                                  </div>
                                  <script type="text/javascript">
                
                                            $('#pwd, #confirmpwd').on('keyup', function () {
                                              if ($('#pwd').val() == $('#confirmpwd').val()) {
                                                $("#resetpwd").prop('disabled', false);
                                                $('#message').html('Matching').css('color', 'green');
                                                
                                              } else {
                                                $('#message').html('Not Matching').css('color', 'red');
                                                $("#resetpwd").prop('disabled', true);
                                              }
                                            });
                                </script>
                                
                                    </form>
                                    </div>
                                </div>
                              </div>
                            </div>
                            
                    </div>
                </main>
                
              <br> <br/>  
  
<?php
             
  if(isset($_POST['reset'])){  
 $oldpassword =  mysqli_real_escape_string($con,$_POST['oldpassword']); 
 $password =  mysqli_real_escape_string($con,$_POST['password']);
 $confirmpassword =  mysqli_real_escape_string($con,$_POST['confirmpassword']);
  
  //Validate old password
 $query = mysqli_query($con,"select * from abcnetsong_login where cetid='$user_id' and is_active=1 LIMIT 1");
$no_rows=mysqli_num_rows($query);
$row = mysqli_fetch_assoc($query);
$passwordHashed = $row['pwd'];


if($no_rows>0 && password_verify($oldpassword, $passwordHashed)){
     
   $password = password_hash($password, PASSWORD_DEFAULT);
 
//  echo "<script type='text/javascript'>alert('$password');</script>";
 
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
  
     $Update=("UPDATE `abcnetsong_login` SET pwd ='$password',forgotPwdCreatedOn ='$current_date',forgotPwdId='$user_id' WHERE cetid = '$user_id' and is_active=1 ");
     
     if (mysqli_query($con, $Update)) {

 ?>
  
      <script>
        
        alert('Password Reset Successfully');
		
		window.location.assign("profile.php");
        
      </script>
        
  <?php  
  }
     
else{
    
    echo '<script>alert("Something is wrong! Please try again");</script>';
    
    // echo "Error: " . $sql . "<br>" . mysqli_error($con);
	
 } 

 }
 
}

?>

            
     <?php include("../footer.php"); ?>	


<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
