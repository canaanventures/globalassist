<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



// echo "<script type='text/javascript'>alert('$user_id');</script>";

function add($con)
    {     
                    
              
                       echo '<table id="example1" class="table table-bordered table-striped">
                                        <thead style="text-align: center;">
                                            <tr>
                                                <th scope="col">S.No</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Description</th>
                                                <th scope="col" style="width:150px;">Active / Inactive</th>
                                                <th scope="col" style="width:80px;">Edit</th>
                                            </tr>
                                        </thead>';
                               
                           
                                $sign ="SELECT * FROM categories where categories_is_active<5";
                                $result=mysqli_query($con,$sign);
                                
                                $var = 1;
                                while($row = mysqli_fetch_array($result))
                                {
                                     
                                    $id=$row["categories_id"];
                                    $categories_name = $row['categories_name'];
                                    $categories_description =$row['categories_description'];
                                    $no_songs = $row['insert_songs'];	
                                    $is_active =$row['categories_is_active'];
                                    
                                     if($is_active==1){
                                        $data="la-eye";
                                        
                                    } elseif ($is_active==0){
                                         $data="la-eye-slash";
                                        
                                    }
                                                
                    
                                      echo '<tr style="text-align: center;">';
                                      echo '<td data-title="S.No.">'.$var++.'</td>';
                                      echo '<td data-title="Name" style="text-transform: capitalize;">' .$categories_name. '</td>';
                                      echo '<td data-title="Description">'.$categories_description.'</td>';
                                      
                                      echo '<td data-title="Active/Inactive" ><a type="button" href="category_active.php?Id='.$id.'" data-toggle="tooltip" title="Active / Inactive" data-placement="left">
                                      <i class="la '.$data.'" style="font-size:20px;" ></i></a></td>';
                                      
                                      echo '<td data-title="Edit" style="font-size:19px;" ><a href="category_edit.php?editId=' .$id. '" ><span class="icon la la-edit"></span></a></td>';
                                     echo '</tr>';
                                     
                                 
                                  }
                                
                                    
                            echo '</table>';
        
    }
   
   
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>

<style>
    .dataTables_length {
         margin-bottom: 35px;
}
</style>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                <div class="container-fluid mt-5">
                    
                <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                      <div class="col-sm-6">
                        <h5 class="m-0 text-dark">Category</h5>
                      </div><!-- /.col -->
                      <div class="col-sm-6" align="right">
                          
                          <a type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Add Category</a>
                         
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        
                        <div class="panel-body mt-5">
                            
                             <div id="no-more-tables" style="clear: both;">       
                                <?php echo add($con);?>
					         </div>
					  
                        </div>
                    </div>
                </main>
          
          
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add Category</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <form id=""  action="" method="post" enctype="multipart/form-data"> 
                                      <div class="form-group">
                                        <label for="recipient-name" class="col-form-label">Name :</label>
                                        <input type="text" class="form-control" id="recipient-name" name="title">
                                      </div>
                                      <div class="form-group mb-5">
                                        <label for="recipient-name" class="col-form-label">Descrption :</label>
                                        <input type="text" class="form-control" name="descrption">
                                      </div>
                                      
                                  <div class="modal-footer">
                                    <button class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button name="submit" class="btn btn-primary">Submit</button>
                                  </div>
                                    </form>
                                    </div>
                                </div>
                              </div>
                            </div>
                            
                    
                    
       
                <?php include("../footer.php"); ?>	

<?php
             
  if(isset($_POST['submit'])){  
   
  $title = mysqli_real_escape_string($con,$_POST['title']);
  $descrption = mysqli_real_escape_string($con,$_POST['descrption']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
  
  $sql="INSERT INTO categories(`categories_name`,`categories_description`,`categories_created_on`,`categories_created_by`) VALUES
  ('$title','$descrption','$current_date','$user_id')";
  
  
  if (mysqli_query($con, $sql)) {
    

       ?>
  
      <script>
        
        alert('Added Successfully');
		
		window.location.assign("category.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("category.php");</script>';

// 		 echo "Error: " . $sql . "<br>" . mysqli_error($con);
      }


   }

?>

<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
