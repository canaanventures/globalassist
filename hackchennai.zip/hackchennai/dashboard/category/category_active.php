<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



// echo "<script type='text/javascript'>alert('$user_id');</script>";


$id = $_GET['Id'];

 $val1 = abs($is_active-=1);
  
   $sql= ("UPDATE `categories` SET categories_is_active=IF(categories_is_active=1, 0, 1) WHERE categories_id='$id'");

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("category.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("category.php");</script>';
		 
      }
?>

