<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}




$id = $_GET['editId'];


$sql = "SELECT * FROM categories WHERE categories_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));
  

// echo "<script type='text/javascript'>alert('$ff');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="category.php">Category</a></li>
                                      <li class="breadcrumb-item active">Edit Category</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
              <h6>Basic Info</h6>
              
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                <div class="row mb-2">
                  <div class="form-group col-7">
                    <label for="title">Category Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo $output["categories_name"]; ?>" >
                  </div>
                  </div>
                  <div class="row">
                  <div class="col-7">
                      <label for="text">Description</label>
                    <input type="text" class="form-control" name="description" value="<?php echo $output["categories_description"]; ?>" >
                  </div>
                  </div>
                  
                </div>
                 
                  <button type="submit" name="submit" class="btn btn-primary mt-5">Update</button>
                
              </form>
            </div>
           
        </div>    
  </div>

  
  <?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $description = mysqli_real_escape_string($con,$_POST['description']);
 
 
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
//Image upload function

function Uploadimage($photo1,$var) {
        
global $folderpath;
  $target = "../upload/$folderpath";
  
          //Employee photo upload
  if ($_FILES[$photo1]['name'] !=""){
  $passportphoto=basename( $_FILES[$photo1]['name']);
  $extension = end(explode(".", $passportphoto));
  $passportphoto=$var."_".uniqid().".".$extension;
  //echo $extension;
  
  $passportphotopath= $target . $passportphoto;
//   echo "<script type='text/javascript'>alert('$passportphotopath');</script>";
  if(move_uploaded_file($_FILES[$photo1]['tmp_name'], $passportphotopath)) {
    
    //Tells you if its all ok
    //echo "The file ". basename( $_FILES[$photo1]['name']). " has been uploaded, and your information has been added to the directory";
  }
return $passportphoto;

}
}
 
$sql=("UPDATE `categories` SET categories_name='$name',categories_description='$description',categories_created_by='$user_id',categories_created_on='$current_date' WHERE categories_id='$id'");
  
  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Successfully Updated');
		
		window.location.assign("category.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT UPDATED.");</script>'; 
		 echo '<script> window.location.assign("category.php");</script>';

    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
