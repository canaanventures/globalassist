<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


date_default_timezone_set('Asia/Kolkata');
$current_date =  date('d-m-Y H:i:s');
 
$id = $_GET['deleteId'];

$sql= "UPDATE `language` SET is_active='9' WHERE language_ID='$id'";

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Deleted Successfully');
		
		window.location.assign("language.php");
     </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. DATA NOT DELETED.");</script>'; 
		 echo '<script> window.location.assign("language.php");</script>';
		 
      }
?>

