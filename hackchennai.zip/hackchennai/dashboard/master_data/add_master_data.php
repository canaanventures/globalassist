<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}

// echo "<script type='text/javascript'>alert('$user_id');</script>";


?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
   <link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">
</head>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="master_data.php">Master Data</a></li>
                                      <li class="breadcrumb-item active">Add Master Data</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <!--<div class="col-sm-6" align="right">-->
                                      
                                  <!--    <button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Create Event </button>-->
                                      
                                  <!--</div>
                                  <!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-8">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
             
              <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="title">Name</label>
                    <input type="text" class="form-control" name="name" required>
                  </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" class="form-control" id="description" required></textarea>
                </div>
             </div>    
                  <button type="submit" name="submit" class="btn btn-primary mt-4">Submit</button>
                
              </form>
            </div>
           
        </div>    
  </div>


<?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $description = mysqli_real_escape_string($con,$_POST['description']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
   $sql="INSERT INTO `lang_master`( `langmas_data`,`langmas_remarks`, `langmas_createdon`,`langmas_createdby`) VALUES 
                  ('$name','$description', '$current_date','$user_id')";

  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Added Successfully');
		window.location.assign("master_data.php");
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 
        echo '<script> window.location.assign("master_data.php");</script>';
    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

   
  </div>
</main>
<br/><br/>  

<?php include("../footer.php"); ?>	


</body>
</html>
