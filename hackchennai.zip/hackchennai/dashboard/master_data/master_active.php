<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['Id'];

 $val1 = abs($langmas_isactive-=1);
  
   $sql= ("UPDATE `lang_master` SET langmas_isactive=IF(langmas_isactive=1, 0, 1) WHERE langmas_id='$id'");

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("master_data.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("master_data.php");</script>';
		 
      }
?>

