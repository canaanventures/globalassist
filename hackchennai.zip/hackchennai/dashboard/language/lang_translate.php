<?php 

session_start();

$_SESSION['id'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

// echo "<script type='text/javascript'>alert('$user_id');</script>";


$id = $_GET['Id'];

 $val1 = abs($is_translate-=1);
  
   $sql= ("UPDATE `language` SET is_translate=IF(is_translate=1, 0, 1) WHERE language_ID='$id'");

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("language.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("language.php");</script>';
		 
      }
?>

