<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


// echo "<script type='text/javascript'>alert('$user_id');</script>";



function add($con)
    {     
                    
          
                       echo '<table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col" style="width:30px;">S.No</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Phone_No</th>
                                                <th scope="col">Email ID</th>
                                                <th scope="col">Message</th>
                                                <th scope="col">Type</th>
                                                <th scope="col">Delete</th>
                                            </tr>
                                        </thead>';
                               
                           
                                $query ="SELECT * FROM form ";
                                $result=mysqli_query($con,$query);
                                
                                $var = 1;
                                while($row = mysqli_fetch_array($result))
                                {
                                    
                                    $id=$row['form_ID'];
                                    
                                    $name = $row['name'];
                                    $countrycode = $row['countrycode'];
                                    $mobile =$row['phone_no'];
                                    $email=$row['email'];
                                    $subject =$row['subject'];
                                    $message=$row['message'];
                                    $type =$row['type'];
                                    $date =$row['created_on'];
                                    $date1 = explode(" ",$date)[0];
                                    
                                    $is_active =$row['is_active'];
                                    
                                     if($is_active==1){
                                        $data="la-eye";
                                        
                                    } elseif ($is_active==0){
                                         $data="la-eye-slash";
                                        
                                    }
                                    
                                     $is_admin =$row['is_admin'];
                                      if($is_admin==1){
                                        $output="la-eye";
                                        
                                    } elseif ($is_admin==0){
                                         $output="la-eye-slash";
                                        
                                    }
                                    
                                    $query = mysqli_query($con,"select name from abcnetsong_login where cetid='$created_by' LIMIT 1");
                                    
                                    $row=mysqli_fetch_assoc($query);
                                    
                                    $created_by=$row['name'];
                                    
                                  
                                      echo ' <tr>';
                                      echo '<td data-title="S.No." >'.$var++.'</td>';
                                      echo '<td data-title="Name" style="text-transform: capitalize;">' .$name. '</td>';
                                      echo '<td data-title="Phone_no">' .$mobile. '</td>';
                                      echo '<td data-title="email">' .$email. '</td>';
                                      echo '<td data-title="Message">' .$message. '</td>';
                                      echo '<td data-title="Type">'.$type.'</td>';
                                      echo '<td data-title="Delete" style="text-align: center;font-size:19px;" >
                                       <a href="form_delete.php?deleteId=' .$id. '" ><span class="icon la la-trash"></span></a></td>';
                                    
                                       ?>
                                       
                                   
                                    
                                      <?php 
                                       
                                       echo'</td>'; 
                                      echo '</tr>';
                                     
                                 
                                  }
                                  
                                    
                            echo '</table>';
        
    }
   
   
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>

<style>
    .dataTables_length {
         margin-bottom: 35px;
}


</style>

<body>

<?php include("../header.php"); ?>

    <div id="layoutSidenav_content">
        <main>
           
        <div class="container-fluid mt-5 mb-5">
          
           <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                      <div class="col-sm-6">
                        <h5 class="m-0 text-dark">Enquiry Form</h5>
                      </div><!-- /.col -->
                      <div class="col-sm-6" align="right">
                          
                          <!--<a type="button" class="btn btn-primary btn-sm" href="add_user.php"><span class="icon la la-plus-square"></span>Add User</a>-->
                         
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
                        
                        
    <div class="panel-body mt-5">
        
         <div id="no-more-tables" style="clear: both;">       
            <?php echo add($con);?>
         </div>
  
    </div>
    
        </div>
    </main>



<?php include("../footer.php"); ?>	

<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
