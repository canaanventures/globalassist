<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


$albumID = $_GET['albumID'];

$sql = "SELECT * FROM album WHERE album_id='$albumID'";  
$album_output = mysqli_fetch_array(mysqli_query($con, $sql));

     $album_lang_id = $album_output['album_lang_id'];
     $album_category_id = $album_output['album_category_id'];
     
     
// echo "<script type='text/javascript'>alert('$ID');</script>";
 
    
function fill_language($con)  
{  
          
        //   global $album_lang_id;
          
          $output = '';  
        //   if($album_lang_id!=""){
              
          $sql = "SELECT `language`, `language_ID` FROM `language` where insert_songs=1 ORDER BY `language_ID` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
               
               $output .= '<option value="'.$row["language_ID"].'">'.$row["language"].'</option>';  
          } 
           
         
          return $output;  
} 

function fill_category($con)  
{  
          
        //   global $album_category_id;
          
          $output = '';  
          
        //   if($album_category_id!=""){
              
          $sql = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_is_active=1 ORDER BY `categories_id` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
              
               $output .= '<option value="'.$row["categories_id"].'">'.$row["categories_name"].'</option>';  
          }  
         
          return $output;  
} 

function fill_sub_type($con){
 //   global $album_category_id;
          
          $output = '';  
          
        //   if($album_category_id!=""){
              
          $sql = "SELECT `types_sub_name`, `types_sub_id` FROM `types_sub` where types_sub_is_active=1 ORDER BY `types_sub_id` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
              
               $output .= '<option value="'.$row["types_sub_id"].'">'.$row["types_sub_name"].'</option>';  
          }  
         
          return $output;  
}

function fill_age($con){
 //   global $album_category_id;
          
          $output = '';  
          
        //   if($album_category_id!=""){
              
          $sql = "SELECT `age_name`, `age_id` FROM `age` where age_is_active=1 ORDER BY `age_id` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
              
               $output .= '<option value="'.$row["age_id"].'">'.$row["age_name"].'</option>';  
          }  
         
          return $output;  
}

function fill_type($con)  
{  
          
        //   global $album_category_id;
          
          $output = '';  
          
        //   if($album_category_id!=""){
              
          $sql = "SELECT `types_name`, `types_id` FROM `types` where types_is_active=1 ORDER BY `types_id` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
              
               $output .= '<option value="'.$row["types_id"].'">'.$row["types_name"].'</option>';  
          }  
         
          return $output;  
} 




// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="data.php">Songs</a></li>
                                      <li class="breadcrumb-item active">Add Data</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
             
              
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Title</label> [<strong> In Native </strong>]
                    <input type="text" class="form-control" name="name" required>
                  </div>
                  
                  <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="Category" >Category</label>
                       <select name="category" class="form-control" required>
                             <?php  echo fill_category($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                      <label for="release" >Type</label>
                     <select name="type" class="form-control" required>
                             <?php  echo fill_type($con); ?>
                      </select>
                   </div>
                   </div>
                     
                 </div>
                 
                  <div class="row mt-4 mb-4">
                  <div class="col-6">
                     <label for="album" >Age</label>
                       <select name="age" class="form-control" required>
                             <?php  echo fill_age($con); ?>
                      </select>
                  </div>
                  
                  <div class="col-6">
                     <label for="language" >Language</label>
                       <select name="language" class="form-control" required>
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                </div>
                
                 <div class="row mt-4 mb-4">
                  <div class="col-3">
                     <label for="album" >Link Type</label>
                       <select name="subtype" class="form-control" required>
                             <?php  echo fill_sub_type($con); ?>
                      </select>
                  </div>
                  
                  <div class="col-6">
                     <label for="language" >Link Url</label>
                       <input type="text" class="form-control" name="url" >
                  </div>
                  <div class="col-3">
                      <i class="las la-plus-circle" onclick="myFunction(document.getElementById('linkDIV'))" style="font-size: 36px;padding-top: 30px"></i>
                  </div>
                </div>
                
                
                 <div id="linkDIV" class="row mt-4 mb-4" style="display:none">
                  <div class="col-3">
                       <select name="subtype" class="form-control" required>
                             <?php  echo fill_sub_type($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                       <input type="text" class="form-control" name="url" >
                  </div>
                  <div class="col-3">
                      <i class="las la-plus-circle" onclick="myFunction(document.getElementById('linkDIV1'))" style="font-size: 36px;"></i>
                      <i class="las la-minus-circle" onclick="hide(document.getElementById('linkDIV'))" style="font-size: 36px;"></i>
                    </div>
                </div>
                
                <div id="linkDIV1" class="row mt-4 mb-4" style="display:none">
                  <div class="col-3">
                       <select name="subtype" class="form-control" required>
                             <?php  echo fill_sub_type($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                       <input type="text" class="form-control" name="url" >
                  </div>
                  <div class="col-3">
                      <i class="las la-plus-circle"   onclick="myFunction(document.getElementById('linkDIV2'))" style="font-size: 36px;"></i>
                      <i class="las la-minus-circle" onclick="hide(document.getElementById('linkDIV1'))" style="font-size: 36px;"></i>
                    </div>
                </div>
                
                 <div id="linkDIV2" class="row mt-4 mb-4" style="display:none">
                  <div class="col-3">
                       <select name="subtype" class="form-control" required>
                             <?php  echo fill_sub_type($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                       <input type="text" class="form-control" name="url" >
                  </div>
                  <div class="col-3">
                      <i class="las la-plus-circle"   onclick="myFunction(document.getElementById('linkDIV3'))" style="font-size: 36px;"></i>
                      <i class="las la-minus-circle" onclick="hide(document.getElementById('linkDIV2'))" style="font-size: 36px;"></i>
                    </div>
                </div>
                
                 <div id="linkDIV3" class="row mt-4 mb-4" style="display:none">
                  <div class="col-3">
                       <select name="subtype" class="form-control" required>
                             <?php  echo fill_sub_type($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                       <input type="text" class="form-control" name="url" >
                  </div>
                  <div class="col-3">
                      <i class="las la-minus-circle" onclick="hide(document.getElementById('linkDIV3'))" style="font-size: 36px;"></i>
                    </div>
                </div>
                
                  
                  
                   
                  
                 <div class="form-group">
                  <label for="textarea-field">Discription</label>
                  <textarea name="lyricscontent" class="form-control" id="textarea-field" required></textarea>
                 </div>
              
              <script>
                function myFunction(x) {
                              //var x = document.getElementById(divid);
                              if (x.style.display === "none") {
                                x.style.display = "flex";
                              }  
                            }
                 function hide(y) {
                              //var x = document.getElementById("linkDIV");
                              if (y.style.display === "flex") {
                                y.style.display = "none";
                              }  
                            }                
               
                  function expandTextarea(id) {
                            document.getElementById(id).addEventListener('keyup', function() {
                                this.style.overflow = 'hidden';
                                this.style.height = 0;
                                this.style.height = this.scrollHeight + 'px';
                            }, false);
                        }
                        
                        expandTextarea('textarea-field');
              </script>
              
                 <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="tag" >Content Tag</label>
                        <input type="text" class="form-control" name="tag" >
                  </div>
                 </div> 
                 
                   <h6>Thumbnail</h6>
             	<div class="image-upload-wrap mb-3">
                  <div class="drag-text" align="center">
                    <input type="file" id="file1" name="image1" class="form-control-file" accept="image/gif, image/jpeg, image/png"  required>
                  </div>
                </div>	
                  <!--<script>-->
                  <!--    var uploadField = document.getElementById("file1");-->

                  <!--      uploadField.onchange = function() {-->
                  <!--          if(this.files[0].size > 10000000){-->
                  <!--             alert("File is too big!");-->
                  <!--             this.value = "";-->
                  <!--          };-->
                  <!--      };-->
                  <!--</script>-->
               
              
                 
                  
                </div>
                 
                  <button type="submit" name="submit" class="btn btn-primary mt-5">Submit</button>
                
              </form>
            </div>
           
        </div>    
  </div>

  
  <?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $category = mysqli_real_escape_string($con,$_POST['category']);
  $type = mysqli_real_escape_string($con,$_POST['type']);
  $age = mysqli_real_escape_string($con,$_POST['age']);
  $subtype = mysqli_real_escape_string($con,$_POST['subtype']);
  $language = mysqli_real_escape_string($con,$_POST['language']);
  $link = mysqli_real_escape_string($con,$_POST['url']);
  
   
   
  $lyricscontent = mysqli_real_escape_string($con,$_POST['lyricscontent']); 
  
  $tag = mysqli_real_escape_string($con,$_POST['tag']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
//Image upload function

function Uploadimage($photo1,$var) {
        
global $folderpath;
  $target = "../upload/$folderpath";
  
          //Employee photo upload
  if ($_FILES[$photo1]['name'] !=""){
  $passportphoto=basename( $_FILES[$photo1]['name']);
  $extension = end(explode(".", $passportphoto));
   $passportphoto=thumbnail."_".$var."_".uniqid().".".$extension;
  //echo $extension;
  
  $passportphotopath= $target . $passportphoto;
//   echo "<script type='text/javascript'>alert('$passportphotopath');</script>";
  if(move_uploaded_file($_FILES[$photo1]['tmp_name'], $passportphotopath)) {
    
    //Tells you if its all ok
    echo "The file ". basename( $_FILES[$photo1]['name']). " has been uploaded, and your information has been added to the directory";
  }
return $passportphoto;

}
}
 
  $track=Uploadimage('image1',track);
 

 $sql="INSERT INTO data (`data_title`, `categories_id`,`types_id`,`age_id`, `language_ID`, `types_sub_id`, `link`,`data_content`,`data_tags`,`data_thumbnail`, `data_created_by`,`data_created_on`) VALUES
  ('$name', '$category', '$type','$age', '$language', '$subtype', '$link','$lyricscontent', '$tag','$track','$user_id','$current_date')";
  

  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('data Added Successfully');
		
		window.location.assign("song.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		// echo '<script> window.location.assign("song.php");</script>';

    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
