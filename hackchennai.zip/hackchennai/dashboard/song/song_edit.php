<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['editId'];
        
$sql = "SELECT * FROM song WHERE song_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));

     $song_album_id = $output['song_album_id'];
     $song_language_id = $output['song_language_id'];
     $song_categeory_id = $output['song_categeory_id'];
 
$insert = "SELECT `album_name`,  `album_id` FROM `album` where album_id='$song_album_id' "; 
$sign = mysqli_fetch_array(mysqli_query($con, $insert));  
        
    $album_name = $sign['album_name'];
    $album_id = $sign['album_id'];

$query = "SELECT `language`, `language_ID` FROM `language` where language_ID='$song_language_id'"; 
$row = mysqli_fetch_array(mysqli_query($con, $query));  
        
    $language = $row['language'];
    $language_ID =$row['language_ID'];

$team = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_id='$song_categeory_id' "; 
$assign = mysqli_fetch_array(mysqli_query($con, $team));  
        
    $categories_name = $assign['categories_name'];
    $categories_id = $assign['categories_id'];

 
function fill_album($con)  
{  
           
          $output = '';  
          $sql = "SELECT `album_name`,  `album_id` FROM `album` where album_is_active=1 ORDER BY `album_id` ASC "; 
          $result = mysqli_query($con, $sql);  
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["album_id"].'">'.$row["album_name"].'</option>';  
          }  
          return $output;  
} 
    
function fill_language($con)  
{  
          
          
          $output = '';  
          $sql = "SELECT `language`, `language_ID` FROM `language` where insert_songs=1 ORDER BY `language_ID` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["language_ID"].'">'.$row["language"].'</option>';  
          }  
          return $output;  
} 

function fill_category($con)  
{  
          
          $output = '';  
          $sql = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_is_active=1 ORDER BY `categories_id` ASC ";  
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["categories_id"].'">'.$row["categories_name"].'</option>';  
          }  
          return $output;  
} 






// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="song.php">Song</a></li>
                                      <li class="breadcrumb-item active">Edit Song</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
             
                
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Song Name</label> [<strong> In English </strong>]
                    <input type="text" class="form-control" name="name" value="<?php echo $output["song_name"]; ?>" >
                  </div>
                 
                   <div class="form-group">
                    <label for="title">Song Alias Name</label>
                    <input type="text" class="form-control" name="alias_name" value="<?php echo $output["song_name_alias"]; ?>" >
                  </div>
                  
                 <div class="form-group">
                  <label for="textarea-field">Lyrics</label>
                  <textarea name="lyricscontent" class="form-control" id="textarea-field" rows="15" ><?php echo $output["lyrics"]; ?></textarea>
                 </div>
              
              <script>
                  function expandTextarea(id) {
                            document.getElementById(id).addEventListener('keyup', function() {
                                this.style.overflow = 'hidden';
                                this.style.height = 0;
                                this.style.height = this.scrollHeight + 'px';
                            }, false);
                        }
                        
                        expandTextarea('textarea-field');
              </script>
              
                  
                  <div class="form-group">
                    <label for="title">Song Credits</label>
                     <textarea class="form-control" name="credits" id="credit-textarea-field"><?php echo $output["song_credits"]; ?></textarea>
                  </div>
                  
                  <script>
                  function expandTextarea(id) {
                            document.getElementById(id).addEventListener('keyup', function() {
                                this.style.overflow = 'hidden';
                                this.style.height = 0;
                                this.style.height = this.scrollHeight + 'px';
                            }, false);
                        }
                        
                        expandTextarea('credit-textarea-field');
              </script>
              
                  
                  <div class="row mt-4 mb-4">
                  <div class="col-6">
                     <label for="album" >Album</label>
                       <select name="album" class="form-control" >
                            <option value="<?php echo $album_id ?>" ><?php echo $album_name ?></option>
                             <?php  echo fill_album($con); ?>
                      </select>
                  </div>
                  
                  <div class="col-6">
                     <label for="language" >Language</label>
                       <select name="language" class="form-control" >
                             <option value="<?php echo $language_ID ?>" ><?php echo $language ?></option>
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                </div>
                <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="Category" >Category</label>
                       <select name="category" class="form-control" >
                              <option value="<?php echo $categories_id ?>" ><?php echo $categories_name ?></option>
                             <?php  echo fill_category($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                     <label for="release" >Release Date</label>
                      <input id="datepicker" class="form-control" name="date" value="<?php echo $output["song_release_date"]; ?>" > 
                   </div>
                      <script>
                        $('#datepicker').datepicker({
                            uiLibrary: 'bootstrap4',
                            format: 'dd/mm/yyyy'
                        });
                    </script>
                 </div>
                 <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="tag" >Song Tag</label>
                        <input type="text" class="form-control" name="tag" value="<?php echo $output["song_tags"]; ?>" >
                  </div>
                 </div> 
                 
                   <h6>Track</h6>
             	<div class="image-upload-wrap mb-3">
                  <div class="drag-text" align="center">
                    <input type="file" id="file1" name="image1" class="form-control-file" accept="audio/*">
                      <br>
                       <audio controls>
                         <source src=<?echo "../upload/" .$output["song_track"] ;?> type="audio/mpeg">
                         Your browser does not support the audio element.
                      </audio>
                  </div>
                </div>	
                  <script>/* 200 KB */
                      var uploadField = document.getElementById("file1");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 1000000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
               
               <h6>Minus track</h6>
             	<div class="image-upload-wrap mb-3">
                  <div class="drag-text" align="center">
                    <input type="file" id="file2" name="image2" class="form-control-file" accept="audio/*">
                    <br>
                       <audio controls>
                         <source src=<?echo "../upload/" .$output["song_minus_track"] ;?> type="audio/mpeg">
                         Your browser does not support the audio element.
                      </audio>
                      
                  </div>
                </div>	
                  <script>/* 200 KB */
                      var uploadField = document.getElementById("file2");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 1000000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                 
                 <h6>Chord Sheet <small> (Only PDF )</small></h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <input type="file" id="file3" name="image3" class="form-control-file" accept=".pdf" >
                      <br>
                     <embed src=<?echo "../upload/" .$output["song_chord_sheet"] ;?>  width="150px" height="auto" alt="" />
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file3");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 100000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                  
                  <h6>Self Declaration <small> (PDF Only)</small></h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <input type="file" id="file4" name="image4" class="form-control-file" accept=".pdf" >
                      <br>
                        <embed src=<?echo "../upload/" .$output["self_declaration"] ;?>  width="150px" height="auto" alt="" />
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file4");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 100000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                  
                </div>
                 
                  <button type="submit" name="submit" class="btn btn-primary mt-5">Update</button>
                
              </form>
            </div>
           
        </div>    
  </div>

  
  <?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $alias_name = mysqli_real_escape_string($con,$_POST['alias_name']);
  $lyricscontent = mysqli_real_escape_string($con,$_POST['lyricscontent']);
  $credits = mysqli_real_escape_string($con,$_POST['credits']);
  $album = mysqli_real_escape_string($con,$_POST['album']);
  $language = mysqli_real_escape_string($con,$_POST['language']);
  $category = mysqli_real_escape_string($con,$_POST['category']);
  $date = mysqli_real_escape_string($con,$_POST['date']);
  $tag = mysqli_real_escape_string($con,$_POST['tag']);
  
 
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
//Image upload function

function Uploadimage($photo1,$var) {
        
global $folderpath;
  $target = "../upload/$folderpath";
  
          //Employee photo upload
  if ($_FILES[$photo1]['name'] !=""){
  $passportphoto=basename( $_FILES[$photo1]['name']);
  $extension = end(explode(".", $passportphoto));
    $passportphoto=song."_".$var."_".uniqid().".".$extension;
  //echo $extension;
  
  $passportphotopath= $target . $passportphoto;
//   echo "<script type='text/javascript'>alert('$passportphotopath');</script>";
  if(move_uploaded_file($_FILES[$photo1]['tmp_name'], $passportphotopath)) {
    
    //Tells you if its all ok
    //echo "The file ". basename( $_FILES[$photo1]['name']). " has been uploaded, and your information has been added to the directory";
  }
return $passportphoto;

}
}
 
  
if($_FILES['image1']['name']!=""){
    
  $track=Uploadimage('image1',"image");
}else{
     $track = $output["song_track"];
}

if($_FILES['image2']['name']!=""){
    
  $audio =Uploadimage('image2',"image");
}else{
     $audio = $output["song_minus_track"];
}

if($_FILES['image3']['name']!=""){
    
  $notes =Uploadimage('image3',"image");
}else{
     $notes = $output["song_chord_sheet"];
}

if($_FILES['image4']['name']!=""){
    
  $selfdeclaration =Uploadimage('image4',"image");
}else{
     $selfdeclaration = $output["self_declaration"];
}

$sql=("UPDATE `song` SET song_name='$name',song_name_alias='$alias_name',lyrics='$lyricscontent',song_categeory_id='$category',song_album_id='$album',song_language_id='$language',song_credits='$credits',song_release_date='$date',song_tags='$tag',song_track='$track',song_minus_track='$audio',song_chord_sheet='$notes',self_declaration='$selfdeclaration',song_created_on='$current_date',song_created_by='$user_id' WHERE song_id='$id'");



  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Updated Successfully');
		
		window.location.assign("song.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("song.php");</script>';

    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
