<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['viewId'];
        
$sql = "SELECT * FROM song WHERE song_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));

     $song_album_id = $output['song_album_id'];
     $song_language_id = $output['song_language_id'];
     $song_categeory_id = $output['song_categeory_id'];
    //  $lyrics = nl2br($output["lyrics"]);
     
$insert = "SELECT `album_name`,  `album_id` FROM `album` where album_id='$song_album_id' "; 
$sign = mysqli_fetch_array(mysqli_query($con, $insert));  
        
    $album_name = $sign['album_name'];
    $album_id = $sign['album_id'];

$query = "SELECT `language`, `language_ID` FROM `language` where language_ID='$song_language_id'"; 
$row = mysqli_fetch_array(mysqli_query($con, $query));  
        
    $language = $row['language'];
    $language_ID =$row['language_ID'];

$team = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_id='$song_categeory_id' "; 
$assign = mysqli_fetch_array(mysqli_query($con, $team));  
        
    $categories_name = $assign['categories_name'];
    $categories_id = $assign['categories_id'];

 
function fill_album($con)  
{  
           
          $output = '';  
          $sql = "SELECT `album_name`,  `album_id` FROM `album` where album_is_active=1 ORDER BY `album_id` ASC "; 
          $result = mysqli_query($con, $sql);  
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["album_id"].'">'.$row["album_name"].'</option>';  
          }  
          return $output;  
} 
    
function fill_language($con)  
{  
          
          
          $output = '';  
          $sql = "SELECT `language`, `language_ID` FROM `language` where is_active=1 ORDER BY `language_ID` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["language_ID"].'">'.$row["language"].'</option>';  
          }  
          return $output;  
} 

function fill_category($con)  
{  
          
          $output = '';  
          $sql = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_is_active=1 ORDER BY `categories_id` ASC ";  
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["categories_id"].'">'.$row["categories_name"].'</option>';  
          }  
          return $output;  
} 




// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="song.php">Songs</a></li>
                                      <li class="breadcrumb-item active">View Songs</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
              
              
                
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Song Name</label> [<strong> In English </strong>]
                    <input type="text" class="form-control" name="name" value="<?php echo $output["song_name"]; ?>" disabled>
                  </div>
                 
                 <div class="form-group">
                    <label for="title">Song Alias Name</label>
                    <input type="text" class="form-control" name="alias_name" value="<?php echo $output["song_name_alias"]; ?>" disabled>
                  </div>
                  
                 <div class="form-group">
                  <label for="textarea-field">Lyrics</label>
                  <textarea name="lyricscontent" class="form-control" id="textarea-field" rows="15" disabled><?php echo $output["lyrics"]; ?></textarea>
                 </div>
              
              <script>
                  function expandTextarea(id) {
                            document.getElementById(id).addEventListener('keyup', function() {
                                this.style.overflow = 'hidden';
                                this.style.height = 0;
                                this.style.height = this.scrollHeight + 'px';
                            }, false);
                        }
                        
                        expandTextarea('textarea-field');
              </script>
              
                  <div class="form-group">
                    <label for="title">Song Credits</label>
                    <input type="text" class="form-control" name="credits" value="<?php echo $output["song_credits"]; ?>" disabled>
                  </div>
                  
                  <div class="row mt-4 mb-4">
                  <div class="col-6">
                     <label for="album" >Album</label>
                       <select name="album" class="form-control" disabled>
                            <option value="<?php echo $album_id ?>" ><?php echo $album_name ?></option>
                             <?php  echo fill_album($con); ?>
                      </select>
                  </div>
                  
                  <div class="col-6">
                     <label for="language" >Language</label>
                       <select name="language" class="form-control" disabled>
                             <option value="<?php echo $language_ID ?>" ><?php echo $language ?></option>
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                </div>
                <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="Category" >Category</label>
                       <select name="category" class="form-control" disabled>
                              <option value="<?php echo $categories_id ?>" ><?php echo $categories_name ?></option>
                             <?php  echo fill_category($con); ?>
                      </select>
                  </div>
                  <div class="col-6">
                     <label for="release" >Release Date</label>
                      <input id="datepicker" class="form-control" name="date" value="<?php echo $output["song_release_date"]; ?>" disabled> 
                   </div>
                      <script>
                        $('#datepicker').datepicker({
                            uiLibrary: 'bootstrap4',
                            format: 'dd/mm/yyyy'
                        });
                    </script>
                 </div>
                 <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="tag" >Song Tag</label>
                        <input type="text" class="form-control" name="tag" value="<?php echo $output["song_tags"]; ?>" disabled>
                  </div>
                 </div> 
                 
                   <h6>Track</h6>
             	<div class="image-upload-wrap mb-3">
                  <div class="drag-text" align="center">
                    <!--<input type="file" id="file2" name="image1" class="form-control-file" accept="audio/*">-->
                
                       <audio controls>
                         <source src=<?echo "../upload/" .$output["song_track"] ;?> type="audio/mpeg">
                         Your browser does not support the audio element.
                      </audio>
                  </div>
                </div>	
                  <script>/* 200 KB */
                      var uploadField = document.getElementById("file");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 10000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
               
               <h6>Minus track</h6>
             	<div class="image-upload-wrap mb-3">
                  <div class="drag-text" align="center">
                    <!--<input type="file" id="file2" name="image2" class="form-control-file" accept="audio/*">-->
                    
                       <audio controls>
                         <source src=<?echo "../upload/" .$output["song_minus_track"] ;?> type="audio/mpeg">
                         Your browser does not support the audio element.
                      </audio>
                      
                  </div>
                </div>	
                  <script>/* 200 KB */
                      var uploadField = document.getElementById("file");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 10000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                 
                 <h6>Chord Sheet <small> (Only PDF )</small></h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <!--<input type="file" id="file1" name="image3" class="form-control-file" accept=".pdf" >-->
                      <br>
                     <embed src=<?echo "../upload/" .$output["song_chord_sheet"] ;?>  width="150px" height="auto" alt="" />
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file1");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 1000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                  
                </div>
                 
                  <!--<button type="submit" name="submit" class="btn btn-primary mt-5">Submit</button>-->
                
              </form>
            </div>
           
        </div>    
  </div>



  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
