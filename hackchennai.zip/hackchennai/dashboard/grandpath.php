<?php 

$grandpath ="https://www.freegospelsongs.co.in/dashboard/";
// echo $grandpath;

?>