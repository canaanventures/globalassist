<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}




// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<body>

<?php include("header.php");?>


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h5 class="mt-4"></h5>
                     <div class="row mt-5 mb-4">
                        <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">ARTIST</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-user"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="artist/artist.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            
                              <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">ALBUM</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-leanpub"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="album/album.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            
                              <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">SONGS</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-music"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="song/song.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>   
                    
                   <div class="container-fluid">
                           
                           <?php 
                              
                              $query="SELECT * FROM `abcnetsong_login` WHERE is_active=1";
                              $result1 = mysqli_query($con, $query);  
                              
                              $is_admin = $result['is_admin'];
                              if($is_admin==1){
                              
                                ?>
                                <h5 class="mt-4">Admin</h5>
                                <div class="row mt-4 mb-5">
                                 <div class="col-xl-3 col-md-6">
                                   <div class="card mb-4">
                                     <div class="card-body" align="left">
									   <div class="star-text">LANGUAGE</div>
									     <div class="wrap-icon icon-1">
									      <span class="icon la la-flag-o"></span>
									       </div>
									 	    <p class="card-text"><br></p>
								     	</div>
                                        <div class="card-footer d-flex align-items-center justify-content-between">
                                            <a class="stretched-link" href="language/language.php">View Details</a>
                                        </div>
                                </div>
                            </div>
                            
                             <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">CATEGORY</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-stack-exchange"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="category/category.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">USER</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-user"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="user/user.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">ENQUIRY FORM</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-stack-exchange"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="form/enquiry_form.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">MASTER DATA</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-gg"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="master_data/master_data.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6">
                                <div class="card mb-4">
                                    <div class="card-body" align="left">
									 <div class="star-text">LANG_SLAVE</div>
									 <div class="wrap-icon icon-1">
									 <span class="icon la la-language"></span>
									 </div>
									 	 <p class="card-text"><br></p>
									</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="stretched-link" href="lang_slave/lang_slave.php">View Details</a>
                                    </div>
                                </div>
                            </div>
                            
                            
                         </div> 
                               <?php   
                            
                          } 
                            ?>
                           
                    </div>
                     
                </main>
               
		
<?php include("footer.php"); ?>	


</body>
</html>

	