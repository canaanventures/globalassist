<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


$artistId = $_GET['artistID'];


// echo "<script type='text/javascript'>alert('$ID');</script>";

function fill_artist($con)  
{  
          global $artistId;
          
          $output = '';  
          
          if($artistId!=""){
          
          $sql = "SELECT `artist_name`,  `artist_id` FROM `artist` where artist_id=".$artistId." AND artist_is_active=1 "; 
          $result = mysqli_query($con, $sql);  
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["artist_id"].'">'.$row["artist_name"].'</option>';  
          } 
          }else{
          $sql = "SELECT `artist_name`,  `artist_id` FROM `artist` where artist_is_active=1 group by artist_id"; 
          $result = mysqli_query($con, $sql);  
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["artist_id"].'">'.$row["artist_name"].'</option>';  
          }  
          }
          return $output;  
} 
    
function fill_language($con)  
{  
          
          global $thenet_groupId;
          
          $output = '';  
          $sql = "SELECT `language`, `language_ID` FROM `language` where insert_songs=1 ORDER BY `language_ID` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["language_ID"].'">'.$row["language"].'</option>';  
          }  
          return $output;  
} 

function fill_category($con)  
{  
          
          global $thenet_groupId;
          
          $output = '';  
          $sql = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_is_active=1 ORDER BY `categories_id` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {  
               $output .= '<option value="'.$row["categories_id"].'">'.$row["categories_name"].'</option>';  
          }  
          return $output;  
} 




// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="album.php">Album</a></li>
                                      <li class="breadcrumb-item active">Add Album</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
              
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Album Name</label> [<strong> In Native </strong>]
                    <input type="text" class="form-control" name="name" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="title">Album Alias Name</label>[<strong> In English </strong>]
                    <input type="text" class="form-control" name="alias_name" >
                  </div>
                  
                  <div class="row mt-4 mb-4">
                  <div class="col-6">
                     <label for="artist" >Artist Name</label>
                       <select name="artist" class="form-control" required>
                             <?php  echo fill_artist($con); ?>
                      </select>
                  </div>
                  
                  <div class="col-6">
                     <label for="language" >Language</label>
                       <select name="language" class="form-control" required>
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                </div>
                <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="Category" >Category</label>
                       <select name="category" class="form-control" required>
                             <?php  echo fill_category($con); ?>
                      </select>
                  </div>
                 </div> 
                  <h6>Album Cover Image</h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <input type="file" id="file" name="image3" onchange="return ValidateAuthorImage(event,this)" class="form-control-file" accept="image/*">
                    </div>
                  </div>
                  <!--<script>-->
                  <!--    var uploadField = document.getElementById("file");-->

                  <!--      uploadField.onchange = function() {-->
                  <!--          if(this.files[0].size > 25000){-->
                  <!--             alert("File is too big!");-->
                  <!--             this.value = "";-->
                  <!--          };-->
                  <!--      };-->
                  <!--</script>-->
               
                  
                  <script>
                        function ValidateAuthorImage(event, obj) {
                        var files = event.target.files;
                        var valid = true;
                        var height = 0;
                        var width = 0;
                        var _URL = window.URL || window.webkitURL;
                        for (var i = 0; i < files.length; i++) {
                            var img = new Image();
                            img.onload = function () {
                                height = img.height;
                                width = img.width;
                                
                                // alert(width + " " + height);
                                
                                if (width <= 0 || width != height) {
                                    $("#file").html("Please upload author image in squire.");
                                    obj.value = "";
                                          alert("Height and Width must be square");
                                    return false;
                                   
                                } else {
                                    $("#file").html("");
                                }
                            }
                            img.src = _URL.createObjectURL(files[i]);
                        }
                      }
                      
                      
                   </script>
                   
                </div>
                 
                  <button type="submit" name="submit" class="btn btn-primary mt-5">Submit</button>
                
              </form>
            </div>
           
        </div>    
  </div>

  
  <?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $alias_name = mysqli_real_escape_string($con,$_POST['alias_name']);
  $artist = mysqli_real_escape_string($con,$_POST['artist']);
  $language = mysqli_real_escape_string($con,$_POST['language']);
  $category = mysqli_real_escape_string($con,$_POST['category']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
//Image upload function

function Uploadimage($photo1,$var) {
        
global $folderpath;
  $target = "../upload/$folderpath";
  
          //Employee photo upload
  if ($_FILES[$photo1]['name'] !=""){
  $passportphoto=basename( $_FILES[$photo1]['name']);
  $extension = end(explode(".", $passportphoto));
   $passportphoto=album."_".$var."_".uniqid().".".$extension;
  //echo $extension;
  
  $passportphotopath= $target . $passportphoto;
//   echo "<script type='text/javascript'>alert('$passportphotopath');</script>";
  if(move_uploaded_file($_FILES[$photo1]['tmp_name'], $passportphotopath)) {
    
    //Tells you if its all ok
    //echo "The file ". basename( $_FILES[$photo1]['name']). " has been uploaded, and your information has been added to the directory";
  }
return $passportphoto;

}
}
 
  
if($_FILES['image3']['name']!=""){
    
  $image=Uploadimage('image3',"image");
}else{
     $image = "../upload/dummy.jpeg";
}

 $sql="INSERT INTO album (`album_name`, `album_name_alias`, `album_artist_id`, `album_lang_id`, `album_category_id`,  `album_cover_image`, `album_created_on`, `album_created_by`) VALUES
  ('$name', '$alias_name', '$artist', '$language','$category','$image', '$current_date', '$user_id')";
  

  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Album Added Successfully');
		
		window.location.assign("album.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("album.php");</script>';

    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
