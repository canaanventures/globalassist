<?php 

session_start();

$_SESSION['id'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

// echo "<script type='text/javascript'>alert('$user_id');</script>";


$id = $_GET['Id'];

 $val1 = abs($song_is_active-=1);
  
   $sql= ("UPDATE `song` SET song_is_active=IF(song_is_active=1, 0, 1) WHERE song_id='$id'");

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("album.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("album.php");</script>';
		 
      }
?>

