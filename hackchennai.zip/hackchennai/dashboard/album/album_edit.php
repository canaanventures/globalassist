<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


$id = $_GET['editId'];
        
$sql = "SELECT * FROM album WHERE album_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));

     $album_artist_id = $output['album_artist_id'];
     $album_lang_id = $output['album_lang_id'];
     $album_category_id = $output['album_category_id'];
 
$insert = "SELECT `artist_name`,  `artist_id` FROM `artist` where artist_id='$album_artist_id' "; 
$sign = mysqli_fetch_array(mysqli_query($con, $insert));  
        
    $artist_name = $sign['artist_name'];
    $artist_id = $sign['artist_id'];

$query = "SELECT `language`, `language_ID` FROM `language` where language_ID='$album_lang_id'"; 
$row = mysqli_fetch_array(mysqli_query($con, $query));  
        
    $language = $row['language'];
    $language_ID =$row['language_ID'];

$team = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_id='$album_category_id' "; 
$assign = mysqli_fetch_array(mysqli_query($con, $team));  
        
    $categories_name = $assign['categories_name'];
    $categories_id = $assign['categories_id'];

 
function fill_artist($con)  
{  
          global $album_artist_id; 
          $output = '';  
          $sql = "SELECT `artist_name`,  `artist_id` FROM `artist` where artist_is_active=1 ORDER BY `artist_id` ASC "; 
          $result = mysqli_query($con, $sql);  
          while($row = mysqli_fetch_array($result))  
          {   
               if($album_artist_id==$row["artist_id"]){
               continue;
                }
               $output .= '<option value="'.$row["artist_id"].'">'.$row["artist_name"].'</option>';  
          }  
          return $output;  
} 
    
function fill_language($con)  
{  
          
          global $album_lang_id;
          
          $output = '';  
          $sql = "SELECT `language`, `language_ID` FROM `language` where insert_songs=1 ORDER BY `language_ID` ASC "; 
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
              if($album_lang_id==$row["language_ID"]){
               continue;
                }
               $output .= '<option value="'.$row["language_ID"].'">'.$row["language"].'</option>';  
          }  
          return $output;  
} 

function fill_category($con)  
{  
          global $album_category_id;
          
          $output = '';  
          $sql = "SELECT `categories_name`, `categories_id` FROM `categories` where categories_is_active=1 ORDER BY `categories_id` ASC ";  
          $result = mysqli_query($con, $sql);   
          while($row = mysqli_fetch_array($result))  
          {    
              if($album_category_id==$row["categories_id"]){
               continue;
                }
               $output .= '<option value="'.$row["categories_id"].'">'.$row["categories_name"].'</option>';  
          }  
          return $output;  
} 




// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="album.php">Album</a></li>
                                      <li class="breadcrumb-item active">Add Album</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
             
              
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Album Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo $output["album_name"]; ?>">
                  </div>
                  
                  <div class="form-group">
                    <label for="title">Album Alias Name</label>
                    <input type="text" class="form-control" name="alias_name" value="<?php echo $output["album_name_alias"]; ?>" >
                  </div>
                  
                  <div class="row mt-4 mb-4">
                  <div class="col-6">
                     <label for="artist" >Artist Name</label>
                       <select name="artist" class="form-control" >
                            <option value="<?php echo $artist_id ?>" ><?php echo $artist_name ?></option>
                             <?php  echo fill_artist($con); ?>
                      </select>
                  </div>
                  
                  <div class="col-6">
                     <label for="language" >Language</label>
                       <select name="language" class="form-control" >
                            <option value="<?php echo $language_ID ?>" ><?php echo $language ?></option>
                             <?php  echo fill_language($con); ?>
                      </select>
                  </div>
                </div>
                <div class="row mb-4"> 
                 <div class="col-6">
                     <label for="Category" >Category</label>
                       <select name="category" class="form-control" >
                            <option value="<?php echo $categories_id ?>" ><?php echo $categories_name ?></option>
                             <?php  echo fill_category($con); ?>
                      </select>
                  </div>
                 </div> 
                  <h6>Album Cover Image</h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <input type="file"  id="file" name="image3" class="form-control-file" accept="image/*">
                       <br>
                      <img src=<?echo "../upload/" .$output["album_cover_image"] ;?>  width="150px" height="auto" alt="" />
                      
                    </div>
                  </div>
                  
                  <!--<script>  -->
                  
                  <!--    var uploadField = document.getElementById("file");-->

                  <!--      uploadField.onchange = function() {-->
                  <!--          if(this.files[0].size > 50000){-->
                  <!--             alert("File is too big!");-->
                  <!--             this.value = "";-->
                  <!--          };-->
                        
                  <!--      var height = this.files[0].clientHeight;-->
                  <!--      var width = this.files[0].clientWidth;-->
                  <!--       var imgWidth = this.files[0].width();-->
                  <!--      alert(height);-->
                        
                  <!--      if (height > 100 || width > 100) {-->
                  <!--          alert("Height and Width must not exceed 100px.");
                                  alert(height and width must be square.);-->
                  <!--          return false;-->
                  <!--      }else{-->
                  <!--      alert("Uploaded image has valid Height and Width.");-->
                  <!--          return true;-->
                  <!--      }-->
                        
                  <!--      };-->
                      
                  <!--</script>-->
               
                 
                </div>
                 
                  <button type="submit" name="submit" class="btn btn-primary mt-5">Submit</button>
                
              </form>
            </div>
           
        </div>    
  </div>

  
  <?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $alias_name = mysqli_real_escape_string($con,$_POST['alias_name']);
  $artist = mysqli_real_escape_string($con,$_POST['artist']);
  $language = mysqli_real_escape_string($con,$_POST['language']);
  $category = mysqli_real_escape_string($con,$_POST['category']);
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
//Image upload function

function Uploadimage($photo1,$var) {
        
global $folderpath;
  $target = "../upload/$folderpath";
  
          //Employee photo upload
  if ($_FILES[$photo1]['name'] !=""){
  $passportphoto=basename( $_FILES[$photo1]['name']);
  $extension = end(explode(".", $passportphoto));
   $passportphoto=album."_".$var."_".uniqid().".".$extension;
  //echo $extension;
  
  $passportphotopath= $target . $passportphoto;
//   echo "<script type='text/javascript'>alert('$passportphotopath');</script>";
  if(move_uploaded_file($_FILES[$photo1]['tmp_name'], $passportphotopath)) {
    
    //Tells you if its all ok
    //echo "The file ". basename( $_FILES[$photo1]['name']). " has been uploaded, and your information has been added to the directory";
  }
return $passportphoto;

}
}
 
  
if($_FILES['image3']['name']!=""){
    
  $image=Uploadimage('image3',"image");
}else{
     $image = $output["album_cover_image"];
}

$sql=("UPDATE `album` SET album_name='$name',album_name_alias='$alias_name', album_artist_id='$artist',album_lang_id='$language',album_category_id='$category',album_cover_image='$image',album_created_on='$current_date',album_created_by='$user_id' WHERE album_id='$id'");

  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Updated Successfully');
		
		window.location.assign("album.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("album.php");</script>';

    //   echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	



</body>
</html>
