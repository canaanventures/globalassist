<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


// echo "<script type='text/javascript'>alert('$user_id');</script>";


$id = $_GET['Id'];


$sql = "SELECT album_id FROM album WHERE album_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));
 
 $album_id =$output["album_id"];
 
function add($con)
    {     
                    
              global $album_id;
              global $id;
              
              echo '<div style="text-align: center;"><a href="../song/add_song.php?albumID='.$id.'" class="btn btn-primary" >Add Song</a></div>
                    <table id="example1" class="table table-bordered table-striped">
                                        
                            <thead style="text-align: center;">
                                <tr>
                                    <th scope="col">S.No</th>
                                    <th scope="col">Song_Name</th>
                                    <th scope="col">Song_Release_Date</th>
                                     <th scope="col">Song Track</th>
                                    <th scope="col">Song Is_Active</th>
                                </tr>
                            </thead>';
                   
                           
                                $sign ="SELECT * FROM song where song_album_id='$album_id' ";
                                $result=mysqli_query($con,$sign);
                                
                                $var = 1;
                                while($row = mysqli_fetch_array($result))
                                {
                                     
                                    $song_id=$row["song_id"];
                                    $song_name = $row['song_name'];
                                    $song_release_date =$row['song_release_date'];
                                    $song_track =$row['song_track'];
                                    $song_track =$row['song_track'];
                                    
                                    $song_is_active =$row['song_is_active'];
                                    
                                     if($song_is_active==1){
                                        $data="la-eye";
                                        
                                    } elseif ($song_is_active==0){
                                         $data="la-eye-slash";
                                        
                                    }
                                                
                    
                                      echo '<tr style="text-align: center;">';
                                      echo '<td data-title="S.No.">'.$var++.'</td>';
                                      echo '<td data-title="Song_Name" style="text-transform: capitalize;">
                                            <a href="../song/song_view.php?viewId='.$song_id.'">' .$song_name. '</a></td>';
                                      echo '<td data-title="Song_Release_Date">'.$song_release_date.'</td>';
                                      echo '<td data-title="Song Track"><audio controls><source src="../upload/'.$song_track.'" ></audio></td>';
                                      echo '<td data-title="Active/Inactive" ><a type="button" href="song_is_active.php?Id='.$song_id.'" data-toggle="tooltip" title="Active / Inactive" data-placement="left">
                                      <i class="la '.$data.'" style="font-size:20px;" ></i></a></td>';
                                      
                                     echo '</tr>';
                                     
                                 
                                  }
                                
                                    
                            echo '</table>';
        
    }
   
   
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>

<style>
    .dataTables_length {
         margin-bottom: 35px;
}
</style>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                <div class="container-fluid mt-5">
                    
                <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                     <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="album.php">Album</a></li>
                      <li class="breadcrumb-item active">Album Details</li>
                    </ol>
                                    
                      <div class="col-sm-6" align="right">
                          
                          <!--<a type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Add Category</a>-->
                         
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        
                        <div class="panel-body">
                            
                             <div id="no-more-tables" style="clear: both;">       
                                <?php echo add($con);?>
					         </div>
					  
                        </div>
                    </div>
                </main>
          
                <?php include("../footer.php"); ?>	


<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
