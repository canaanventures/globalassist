<?php 
session_start();

include("grandpath.php");

include("../admin/dbconfig.php");

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}

$sql = "SELECT * FROM abcnetsong_login where cetid='$user_id'";  
$result = mysqli_fetch_array(mysqli_query($con, $sql));  

$name = $result['name'];

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Dashboard</title>
        
       	 <!-- plugins CSS Files -->
        <link href="<?php echo $grandpath?>plugins/icofont/icofont.min.css" rel="stylesheet">
		<link href="plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">
		<link href="<?php echo $grandpath?>css/styles.css" rel="stylesheet" />

		
    </head>
    <body class="sb-nav-fixed">
         <input type="text" placeholder="Search..">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            
            <a class="navbar-brand" ></a>
            
			<div id="sidebarToggle" >
			<button class="btn btn-sm order-1 order-lg-0" href="">
			<span class="icon la la-navicon" style="font-size:22px;color:#fff;"></span></button>
			</div>
			
			<!--<a type="button" class="btn btn-sm order-1 order-lg-0" href="<?php echo $grandpath?>tn_choosegroup.php">-->
			<!--<span class="icon la la-long-arrow-left" style="font-size:22px;color:#fff;"></span></a>-->
			 
			 <p class="headtitle"><?php echo $thenet_groupName ?></p>
			 
			
            <div class="d-none d-md-inline-block ml-auto mr-0 mr-md-3 my-2 my-md-0">
    <!--         <p style="color:#FFF;font-size:19px;margin-top: 18px;">-->
				<!--<span style="text-transform: lowercase;">[Technologies Private]</span></span></p>-->
            </div>
			
            <!-- Navbar-->
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="userDropdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="icon la la-cog" style="color:#9d9fa2;font-size:21px;"></span></a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                       <!--<div class="dropdown-divider"></div>-->
                       
                         <?php if( isset($_SESSION['cetmobile']) && !empty($_SESSION['cetmobile']) )
                           {
                            ?>
                              <a class="dropdown-item" href="<?php echo $grandpath?>../admin/logout.php">Logout</a>
                          
                          <?php }else{ ?>
                        
                            <a class="dropdown-item" href="<?php echo $grandpath?>../admin/logout.php">Logout</a>
                        
                             <?php } ?>
                        
                    <!--</div>-->
                </li>
            </ul>
			
        </nav>
    <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">
							<img src="<?php echo $grandpath?>upload/logo.jpg" align="center" style="width: 100%;">
							<br /><br/>
							 <p> Welcome  &nbsp; <?php echo $name ?></p>
							</div>
							
                            <a class="nav-link" href="<?php echo $grandpath?>index.php">
                                <div class="sb-nav-link-icon"><span class="icon la la-tachometer" style="font-size:22px;"></span></div>
                                Dashboard</a>
                                
                            <a class="nav-link" href="<?php echo $grandpath?>myprofile/profile.php">
                                <div class="sb-nav-link-icon"><span class="icon la la-user" style="font-size:22px;"></span></div>
                                My Profile</a>
                                
                         
                        </div>
                    </div>
                   
                </nav>
            </div>
            