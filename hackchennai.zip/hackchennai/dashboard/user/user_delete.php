<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}




$id = $_GET['deleteId'];

 date_default_timezone_set('Asia/Kolkata');
 $current_date =  date('d-m-Y H:i:s');
  
$sql= "UPDATE `abcnetsong_login` SET deleted_by='$user_id', deleted_on='$current_date',is_active='9' WHERE cetid='$id'";


if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Deleted Successfully');
		
		window.location.assign("user.php");
     </script>
        
  <?php  
  }
      else {
		
		 echo '<script>alert("Error. DATA NOT DELETED.");</script>'; 
		 echo '<script> window.location.assign("user.php");</script>';
		 
      }
?>

