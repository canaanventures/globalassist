<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['Id'];

 $val1 = abs($is_admin-=1);
  
   $sql= ("UPDATE `abcnetsong_login` SET is_admin=IF(is_admin=1, 0, 1) WHERE cetid='$id'");

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("user.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("user.php");</script>';
		 
      }
?>

