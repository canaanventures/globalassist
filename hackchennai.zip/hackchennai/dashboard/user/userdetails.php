<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}



$id = $_GET['viewId'];

$sql = "SELECT * FROM abcnetsong_login WHERE cetid='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));

// echo "<script type='text/javascript'>alert('$user_id');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
   <link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">
</head>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="user.php">User</a></li>
                                      <li class="breadcrumb-item active">Add User</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <!--<div class="col-sm-6" align="right">-->
                                      
                                  <!--    <button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Create Event </button>-->
                                      
                                  <!--</div>
                                  <!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
              <h6>User Details</h6>
              
              <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                
                  <div class="form-group">
                    <label for="title">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo $output["name"]; ?>" disabled>
                  </div>
                    
                <div class="row mb-3">
                  <div class="col-lg-2 col-sm-12">
                      <label for="date">Country</label>
                    <input type="number" class="form-control" name="country" value="<?php echo $output["countrycode"]; ?>" disabled>
                  </div>
                  
                  <div class="col-lg-4 col-sm-12">
                      <label for="date">Mobile No.</label>
                    <input type="number" class="form-control" name="mobile" value="<?php echo $output["mobile"]; ?>" disabled>
                  </div>
                   
                    <div class="col-lg-6 col-sm-12">
                       <label for="date">Email Id</label>
                         <input type="email" id="email" class="form-control" name="email" value="<?php echo $output["email"]; ?>" disabled> 
                    </div>
               </div>
                <!--<div class="form-group">-->
                <!--    <label for="title">pawword</label>-->
                <!--    <input type="text" class="form-control" name="pawword">-->
                <!--</div>-->
                  <!--<button type="submit" name="submit" class="btn btn-primary mt-4">Submit</button>-->
                
              </form>
            </div>
           
        </div>    
  </div>



  </div>
</main>
<br/><br/>  

<?php include("../footer.php"); ?>	


</body>
</html>
