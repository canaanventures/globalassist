<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


// echo "<script type='text/javascript'>alert('$user_id');</script>";



?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="artist.php">Artist</a></li>
                                      <li class="breadcrumb-item active">Add Artist</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
              
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Artist Name</label>
                    <input type="text" class="form-control" name="name" required>
                  </div>
                  
                  <div class="row mb-2">
                  <div class="col-6">
                      <label for="text">Contact Number</label>
                    <input type="number" class="form-control" name="contact" required>
                  </div>
                  
                  <div class="col-6 mb-4">
                      <label for="text">Email ID</label>
                    <input type="email" class="form-control" name="email" required>
                  </div>
                </div>
                 
                  <h6>ID Proof</h6>
                  <h6>Image</h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <input type="file" id="file" name="image3" class="form-control-file" accept="image/*">
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 25000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                   <h6>Address Proof</h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <input type="file" id="file1" name="image4" class="form-control-file" accept="image/*,.pdf" >
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file1");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 1000000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                 
                </div>
                 
                  <button type="submit" name="submit" class="btn btn-primary mt-5">Submit</button>
                
              </form>
            </div>
           
        </div>    
  </div>

  
  <?php
             
  if(isset($_POST['submit'])){  
      
  $name = mysqli_real_escape_string($con,$_POST['name']);
  $contact = mysqli_real_escape_string($con,$_POST['contact']);
  $email = mysqli_real_escape_string($con,$_POST['email']);
 
  
  
  date_default_timezone_set('Asia/Kolkata');
  $current_date =  date('d-m-Y H:i:s');
 
//Image upload function

function Uploadimage($photo1,$var) {
        
global $folderpath;
  $target = "../upload/$folderpath";
  
          //Employee photo upload
  if ($_FILES[$photo1]['name'] !=""){
  $passportphoto=basename( $_FILES[$photo1]['name']);
  $extension = end(explode(".", $passportphoto));
 $passportphoto=artist."_".$var."_".uniqid().".".$extension;
  //echo $extension;
  
  $passportphotopath= $target . $passportphoto;
//   echo "<script type='text/javascript'>alert('$passportphotopath');</script>";
  if(move_uploaded_file($_FILES[$photo1]['tmp_name'], $passportphotopath)) {
    
    //Tells you if its all ok
    //echo "The file ". basename( $_FILES[$photo1]['name']). " has been uploaded, and your information has been added to the directory";
  }
return $passportphoto;

}
}
 
  
if($_FILES['image3']['name']!=""){
    
  $image=Uploadimage('image3',"image");
}else{
     $image = "../upload/dummy.jpeg";
}


//Image upload

  $proof=Uploadimage('image4',proof);
  
  $pgMarksheetphoto=Uploadimage('file2',"pgMark");
  
  $sql="INSERT INTO artist (`artist_name`, `artist_contact`, `artist_mail_id`, `artist_proof`,  `artist_image`, `artist_created_on`, `artist_created_by`) VALUES
  ('$name', '$contact', '$email','$proof','$image', '$current_date', '$user_id')";
  

  if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        alert('Successfully Added');
		
		window.location.assign("artist.php");
         
		 
        </script>
        
  <?php  
  }
      else {
		
// 		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
// 		 echo '<script> window.location.assign("artist.php");</script>';

      echo "Error: " . $sql . "<br>" . mysqli_error($con);
		 
      }


   }
   
?>

  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
