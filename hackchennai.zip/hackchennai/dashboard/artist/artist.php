<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


function fill_media($con)
    { 
           
          echo '<table id="example1" class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">List Of Artist</th>
                        </tr>
                    </thead>';
              
                $query ="SELECT * FROM artist where artist_is_active<5";
                $result=mysqli_query($con,$query);

                while($row = mysqli_fetch_array($result))
                {
                    
                    $id =$row["artist_id"];
                    $artist_name = $row['artist_name'];
                    $artist_contact =$row['artist_contact'];
                    $artist_image =$row['artist_image'];
                    
                    $startdate=$row['artist_created_on'];
                    $date = str_replace('/', '-', $startdate );
                    $newDate = date("F d, Y", strtotime($date));
                     
                   
                    $is_active =$row['artist_is_active'];
                                    
                     if($is_active==1){
                        $data="la-eye";
                        
                    } elseif ($is_active==0){
                         $data="la-eye-slash";
                        
                    }
                                    
                      echo ' <tr>';
                      echo '<td>
                     
                            <div class="row justify-content-between col-lg-12">
                                            <div class="product-img">
                                       <img src="../upload/'.$artist_image.'" alt="Product Image" style="width:65px;height:65px;">
                                    </div>
                                    <div class="col">
                                       <div class="product-info">
                                        <span class="info-box-text"><a href="artist_details.php?Id='.$id.'">'.$artist_name.'</a></span><br>
                                        <span class="info-box-des">'.$newDate.'</span>
                                       </div>
                                    </div>
                                    
                                    <ul class="nav nav-pills ml-auto p-2">
                                      <a type="button" href="artist_active.php?Id='.$id.'" data-toggle="tooltip" title="Active / Inactive" data-placement="left">
                                      <i class="la '.$data.'" style="font-size:20px;padding-right: 10px;"></i>
                                     </a>
                                     
                                     <a type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <i class="la la-ellipsis-v" style="font-size:24px"></i>
                                     </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                       <a class="dropdown-item" tabindex="-1" href="artist_view.php?viewId='.$id.'">View</a>
                                       <a class="dropdown-item" tabindex="-1" href="artist_edit.php?editId='.$id.'">Edit</a>
                                       <a class="dropdown-item" tabindex="-1" href="artist_delete.php?deleteId='.$id.'">Delete</a>
                                    </div>
                                </ul>
                              <div> 
                               
                            </td>';
                        echo '</tr>';
                      }
                echo '</table>';
        
    }
   
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>

<style>
    .dataTables_length {
         margin-bottom: 35px;
}


</style>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                    <h5 class="m-0 text-dark">Artist</h5>
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <a type="button" class="btn btn-primary btn-sm" href="add_artist.php">Add Artist</a>
                                     
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
                   <!--<div class="col-12" align="center">-->
                    <div class="panel-body col-lg-11 mt-5">
                        <?php echo fill_media($con);?>
                    </div>
                  <!--</div>    -->
              <br>
  </div>
</main>
          
 
    <?php include("../footer.php"); ?>	

<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
