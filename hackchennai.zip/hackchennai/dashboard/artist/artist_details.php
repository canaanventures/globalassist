<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


// echo "<script type='text/javascript'>alert('$user_id');</script>";


$id = $_GET['Id'];


$sql = "SELECT artist_id FROM artist WHERE artist_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));
 
 $artist_id =$output["artist_id"];
 
function add($con)
    {     
                    
              global $artist_id;
              global $id;
              
              echo '<div style="text-align: center;"><a href="../album/add_album.php?artistID='.$id.'" class="btn btn-primary" >Add Album</a></div>
                    <table id="example1" class="table table-bordered table-striped">
                            
                            <thead style="text-align: center;">
                                <tr>
                                    <th scope="col">S.No</th>
                                    <th scope="col">Album_Name</th>
                                    <th scope="col">Album_Cover_image</th>
                                    <th scope="col" style="width:150px;">Active / Inactive</th>
                                    
                                </tr>
                            </thead>';
                     
                                $sign ="SELECT * FROM album where album_artist_id='$artist_id' ";
                                $result=mysqli_query($con,$sign);
                                
                                $var = 1;
                                while($row = mysqli_fetch_array($result))
                                {
                                     
                                    $id=$row["album_id"];
                                    $album_name = $row['album_name'];
                                    $album_cover_image =$row['album_cover_image'];
                                    	
                                    $is_active =$row['album_is_active'];
                                    
                                     if($is_active==1){
                                        $data="la-eye";
                                        
                                    } elseif ($is_active==0){
                                         $data="la-eye-slash";
                                        
                                    }
                                                
                    
                                      echo '<tr style="text-align: center;">';
                                      echo '<td data-title="S.No.">'.$var++.'</td>';
                                      echo '<td data-title="Album_Name" style="text-transform: capitalize;"><a href="../album/album_details.php?Id='.$id.'">' .$album_name. '</a></td>';
                                      echo '<td data-title="Album_Cover_image"><img src="../upload/'.$album_cover_image.'" style="width:65px;height:65px;" /></td>';
                                      
                                      echo '<td data-title="Active/Inactive" ><a type="button" href="category_active.php?Id='.$id.'" data-toggle="tooltip" title="Active / Inactive" data-placement="left">
                                      <i class="la '.$data.'" style="font-size:20px;" ></i></a></td>';
                                      
                                    //   echo '<td data-title="Edit" style="font-size:19px;" ><a href="category_edit.php?editId=' .$id. '" ><span class="icon la la-edit"></span></a></td>';
                                    
                                     echo '</tr>';
                                     
                                 
                                  }
                                
                                    
                            echo '</table>';
        
    }
   
   
?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>

<style>
    .dataTables_length {
         margin-bottom: 35px;
}
</style>

<body>

<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                <div class="container-fluid mt-5">
                    
                <div class="content-header">
                  <div class="container-fluid">
                    <div class="row mb-2">
                     <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="artist.php">Artist</a></li>
                      <li class="breadcrumb-item active">Artist Details</li>
                    </ol>
                                    
                      <div class="col-sm-6" align="right">
                          
                          <!--<a type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#exampleModal">Add Category</a>-->
                         
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        
                        <div class="panel-body">
                            
                             <div id="no-more-tables" style="clear: both;">       
                                <?php echo add($con);?>
					         </div>
					  
                        </div>
                    </div>
                </main>
          
                <?php include("../footer.php"); ?>	


<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<!-- DataTables -->
<script src="../plugins/datatables/jquery.dataTables.js"></script>
<script src="../plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

</body>
</html>
