<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


$id = $_GET['viewId'];


$sql = "SELECT * FROM artist WHERE artist_id='$id'";  
$output = mysqli_fetch_array(mysqli_query($con, $sql));
  

// echo "<script type='text/javascript'>alert('$ff');</script>";

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
 <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/line-awesome/css/line-awesome.min.css" rel="stylesheet">

</head>
<body>
  
<?php include("../header.php"); ?>

            <div id="layoutSidenav_content">
                <main>
                   
                    <div class="container-fluid mt-5">
                      
                         <div class="content-header">
                              <div class="container-fluid">
                                <div class="row mb-2">
                                  <div class="col-sm-6">
                                   <ol class="breadcrumb">
                                      <li class="breadcrumb-item"><a href="artist.php">Artist</a></li>
                                      <li class="breadcrumb-item active">View Artist</li>
                                    </ol>
                                   
                                  </div><!-- /.col -->
                                  <div class="col-sm-6" align="right">
                                      
                                      <!--<button class="btn btn-primary btn-sm"><span class="icon la la-calendar-check-o"></span>Save</button>-->
                                      
                                  </div><!-- /.col -->
                                </div><!-- /.row -->
                              </div><!-- /.container-fluid -->
                            </div>
   
  
    <div class="col-md-9">
        <div class="card">
              <div class="container-fluid mt-3 mb-3">
              
               <form id=""  action="" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Artist Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo $output["artist_name"]; ?>" disabled>
                  </div>
                  
                  <div class="row mb-2">
                  <div class="col-6">
                      <label for="text">Contact Number</label>
                    <input type="number" class="form-control" name="contact" value="<?php echo $output["artist_contact"]; ?>" disabled>
                  </div>
                  
                  <div class="col-6 mb-4">
                      <label for="text">Email ID</label>
                    <input type="email" class="form-control" name="email" value="<?php echo $output["artist_mail_id"]; ?>" disabled>
                  </div>
                </div>
                 
                  <h6>ID Proof</h6>
                  <h6>Image</h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                      <!--<input type="file" id="file" name="image3" class="form-control-file" accept="image/*">-->
                       <img src=<?echo "../upload/" .$output["artist_image"] ;?>  width="150px" height="auto" alt="" />
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 200000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                   <h6>Address Proof</h6>
                 <div class="image-upload-wrap mb-3">
                    <div class="drag-text" align="center">
                     <!--<input type="file" id="file1" name="image4" class="form-control-file" accept="image/*,.pdf" >-->
                      
                    <embed src=<?echo "../upload/" .$output["artist_proof"] ;?>  width="300px" height="auto" alt="" />
                    </div>
                  </div>
                  <script>
                      var uploadField = document.getElementById("file1");

                        uploadField.onchange = function() {
                            if(this.files[0].size > 200000){
                               alert("File is too big!");
                               this.value = "";
                            };
                        };
                  </script>
                 
                </div>
                 
                  <!--<button type="submit" name="submit" class="btn btn-primary mt-5">Submit</button>-->
                
              </form>
            </div>
           
        </div>    
  </div>

 
  </div>
</main>
<br>  

<?php include("../footer.php"); ?>	


</body>
</html>
