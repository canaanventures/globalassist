<?php 

session_start();

$_SESSION['id'];
$_SESSION['is_admin'];

$user_id = $_SESSION['id'];

include("../../admin/dbconfig.php");

if($_SESSION['id']==null){
    
    header("Location: ../admin/index.php");
}


$id = $_GET['Id'];

 $val1 = abs($artist_is_active-=1);
  
   $sql= ("UPDATE `artist` SET artist_is_active=IF(artist_is_active=1, 0, 1) WHERE artist_id='$id'");

if (mysqli_query($con, $sql)) {
    
  ?>
  
      <script>
        
        // alert('Updated successfully');
		
		window.location.assign("artist.php");
         
		 
        </script>
        
  <?php  
  }
      else {

		 echo '<script>alert("Error. Form NOT SUBMITTED.");</script>'; 
		 echo '<script> window.location.assign("artist.php");</script>';
		 
      }
?>

