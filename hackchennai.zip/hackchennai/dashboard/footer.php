<?php
include("grandpath.php");
?>
<footer class="py-3 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; crossedge 2020</div>
                            
                        </div>
                    </div>
                </footer>
            </div>
            
        </div>
        
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        
       <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
       <script src="<?php echo $grandpath?>js/scripts.js"></script>
        
    </body>
</html>
